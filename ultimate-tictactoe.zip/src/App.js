import React from 'react';
import UltimateTicTacToe from './ultimate-tictactoe';

function App() {
  return <UltimateTicTacToe />;
}

export default App;
